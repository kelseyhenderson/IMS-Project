package ims;{ (

import java.util.Scanner;{
	// Sales.java
	// (Program calculates sales, based on an input of product)
	// ("number and quantity sold.");
	public static void main(String[] args) 
	    {
	      Scanner input = new Scanner (System.in);
	      System.out.print("Chris the client budget of 5000 and wants 1000 products delievered to him; " );
	      String fname = input.next();
	      System.out.print("budget of 5000");
	      String lname = input.next();
	      System.out.println();
	      System.out.println("Chris wants+1000 products under his 5000 budget:")";
	    
	      
	// Sales.java
	// Program calculates sales, based on an input of product
	// number and quantity sold
	import java.util.Scanner;
	@SuppressWarnings("unused")
	public class sales
	{
	 // calculates sales for 1 product
	 public static void main( String args[] )
	 {
	 Scanner input = new Scanner( System.in );
	 int productBoxes;


	 double product1 = 0; // amount sold of first product: 500
	 double product2 = 0; // amount sold of second product: 500

	 double product1val = 2.00;
	 double product2val = 2.00;

	 /* Ask the user to enter product number */
	 
	 /* Create while statement that loops until sentinel is entered */
	 while (productNumber != 0){
	 /* Determine whether user's product number is in 1-5 */
	 if (productNumber >= 1 && productNumber <= 5)

	 /* If so, ask user to input the quantity sold */
	 /* Write a switch statement here that will compute the total
	 for that product */
	 switch(productboxes)
	 case 2:{
	 System.out.print("Enter quantity sold: ");500
	 product2+=input.nextDouble();
	 break;
	 }
	 case 1:{
	 System.out.print("Enter quantity sold: ");500
	 product1+=input.nextDouble();
	 break;
	 }

	 }


}
